#define _CRT_SECURE_NO_WARNINGS	// So visual studio doesn't complain about deprecated C functions.
                                // Okay to leave this #define in the code even if not using VS.

#include <fstream>
#include "Classifier.h"

using namespace std;

int main(int argc, char** argv)
{  
    if (argc < 6) {
        cout << "Incorrect command line arguments." << endl;
        cout << "Usage:" << endl;
        cout << "\t<train_data_filename>" << endl;
        cout << "\t<test_data_filename>" << endl;
        cout << "\t<test_sentiment_filename>" << endl;
        cout << "\t<results_filename>" << endl;
        cout << "\t<accuracy_errors_filname>" << endl;
        return -1;
    }

    ifstream train_is, tweet_is, sent_is;
    ofstream result_os, acc_err_os;
    train_is.open(argv[1]);
    if (!train_is.is_open()) {
        cout << "Unable to open train data file \"" << argv[1] << '"' << endl;
        return -2;
    }
    tweet_is.open(argv[2]);
    if (!tweet_is.is_open()) {
        cout << "Unable to open test data file \"" << argv[2] << '"' << endl;
        return -3;
    }
    sent_is.open(argv[3]);
    if (!sent_is.is_open()) {
        cout << "Unable to open test sentiment file \"" << argv[3] << '"' << endl;
        return -4;
    }
    result_os.open(argv[4]);
    if (!result_os.is_open()) {
        cout << "Unable to open results file \"" << argv[4] << '"' << endl;
        return -5;
    }
    acc_err_os.open(argv[5]);
    if (!acc_err_os.is_open()) {
        cout << "Unable to open accuracy/error file \"" << argv[5] << '"' << endl;
        return -6;
    }

    Classifier classifier;
    classifier.train(train_is);
    classifier.test(tweet_is, sent_is, result_os, acc_err_os);

    return 0;
}

