#ifndef CLASSIFIER_H
#define CLASSIFIER_H

#include "DSVector.h"
#include "DSString.h"
#include "english_stem.h"

class Classifier {

public:

	void train(std::istream& csv);
	void test(std::istream& csv_tweets, std::istream& csv_sents,
		std::ostream& csv_results, std::ostream& csv_acc_err);

private:

	struct SentimentalWord {
		DSString word;
		int pos_count;// increased by 1 each time the word appears in a positive tweet.
		int neg_count;// increased by 1 each time the word appears in a negative tweet.

		bool operator<(const SentimentalWord& rhs) const { return this->word < rhs.word; }
		// needed for std::sort
	};

	DSVector<SentimentalWord> vocabulary;// Maintains the words sorted in alphabetical order

	int pos_tweet_count;	// total number of tweets encountered during the training
							// phase that were classified as positive sentiment.
	int neg_tweet_count;	// total number of tweets encountered during the training
							// phase that were classified as negative sentiment.

	// Data members used for stemming
	stemming::english_stem<> stemmer;
	std::wstring unicode_word;			// For storing words in unicode format just
	DSVector<wchar_t> unicode_buffer;	// when stemming.
	DSVector<char> ascii_buffer;

	void insert(const DSString& word, int sentiment);

	bool is_positive_tweet(const DSVector<DSString>& words_in_tweet) const;

	int lookup_pos_sentiment(const DSString& word) const;
	int lookup_neg_sentiment(const DSString& word) const;

	void acquire_chapter(Classifier& chapter);

	void stem(DSString& token);
};

#endif
