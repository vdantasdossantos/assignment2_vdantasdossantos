#include "DSString.h"
#include <cstdlib>
#include <cstring>
#include <cassert>
#include <cctype>

// Implement your class.
// You may functions for c-strings in string.h, but use them sparingly
// and implement mostly your own functions.

const char DSString::EMPTY_STRING[1] = { '\0' };

void DSString::copy(const char* copied_string)
{
    size_t new_len = strlen(copied_string);
    reserve(new_len + 1);
    strcpy(data, copied_string);//copying
    len = new_len;
}

void DSString::clear()
{
    if (data != nullptr) {
        delete[] data;
        data = nullptr;
        alloc = 0;
        len = 0;
    }
}

// default ctor
DSString::DSString()
    : data(nullptr), alloc(0), len(0)
{
}

// Constructor from C-style string
DSString::DSString(const char *src) 
    : data(nullptr), alloc(0), len(0)
{
    copy(src);
}

// Copy constructor from DSString
DSString::DSString(const DSString& dss) 
    : data(nullptr), alloc(0), len(0)
{
    copy(dss.c_str());
}

// Destructor
DSString::~DSString()
{
    clear();
}

DSString& DSString::operator=(const DSString &dss) {
    if (this != &dss) {   // Check for self-assignment
        copy(dss.c_str());
    }
    return *this;
}

DSString::DSString(DSString&& dss) noexcept
    : data(dss.data), alloc(dss.alloc), len(dss.len)
{
    dss.data = nullptr;
    dss.alloc = 0;
    dss.len = 0;
}

DSString& DSString::operator=(DSString&& dss) noexcept
{
    if (this != &dss) {   // Check for self-assignment
        clear();

        data = dss.data;
        alloc = dss.alloc;
        len = dss.len;

        dss.data = nullptr;
        dss.alloc = 0;
        dss.len = 0;
    }
    return *this;
}

void DSString::reserve(size_t alloc_request)
{
    if (alloc_request <= alloc) {
        return;
    }

    char* p = data;
    data = new char[alloc_request];
    alloc = alloc_request;
    
    if (p != nullptr) {
        strncpy(data, p, len + 1);
        delete[] p;
        p = nullptr;
    }
}

DSString& DSString::operator+=(const DSString&) {
    // todo
    assert(false);  // function is imcomplete
    return *this;
}

bool DSString::operator==(const DSString& rhs) const
{
    if (len != rhs.len)
        return false;

    return (strcmp(data, rhs.data) == 0);
}

bool DSString::operator!=(const DSString& rhs) const {
    return !(*this == rhs);
}

bool DSString::operator<(const DSString& rhs) const {
    return (strcmp(data, rhs.data) < 0);
}

bool DSString::operator>(const DSString& rhs) const {
    return (strcmp(data, rhs.data) > 0);
}

DSString DSString::substring(size_t pos, size_t count) const
{
    if (pos > len) {
        return EMPTY_STRING;
    }
    if (count > len - pos) {
        count = len - pos;
    }

    DSString sub;
    sub.reserve(count + 1);
    strncpy(sub.data, data + pos, count);
    sub.len = count;
    sub.data[count] = '\0';

    return sub;
}

const char * DSString::c_str() const
{
    if (data == nullptr) {
        return EMPTY_STRING;
    }
    return data;
}

std::ostream &operator<<(std::ostream &os, const DSString &dss)
{
    os << dss.c_str();
    return os;
}

std::istream& operator>>(std::istream& is, DSString& dss)
{
    // todo redo

    // First skip any leading whitespace
    char c;
    bool nonws;
    while ((nonws = (bool)is.get(c)) && isspace(c));

    // If nonwhitespace encountered, read characters up to the next whitespace
    if (nonws) {
        constexpr size_t CHUNK_SIZE = 16;
        char* p = (char*)realloc(dss.data, CHUNK_SIZE);
        if (p == nullptr) {
            return is;
        }
        dss.data = p;
        dss.data[0] = c;
        dss.len = 1;
        while (is.peek() != EOF && !isspace(is.peek())) {
            is.get(c);
            dss.data[dss.len] = c;
            if (++dss.len % (CHUNK_SIZE - 1) == 0) {
                p = (char*)realloc(dss.data, dss.len + CHUNK_SIZE);
                if (p)  dss.data = p;
                else    break;
            }
        }
        p = (char*)realloc(dss.data, dss.len + 1);
        if (p)  dss.data = p;
        dss.data[dss.len] = '\0';
    }
    else {
        dss = DSString();
    }

    return is;
}

DSVector<DSString> DSString::get_tokens(char delim) const
{
    DSVector<DSString> tokens;
    size_t i = 0, j = 0;

    while (j < len) {
        if (data[j] == delim) {
            if (i < j) {
                tokens.push_back(substring(i, j - i));
            }
            i = ++j;
        }
        else {
            j++;
        }
    }

    if (i < j) {
        tokens.push_back(substring(i, j - i));
    }

    return tokens;
}

std::istream& getline(std::istream& is, DSString& dss, char delim)
{
    char c;
    constexpr size_t CHUNK_SIZE = 16;
    dss.len = 0;
    dss.reserve(CHUNK_SIZE);
    while (is.get(c) && (char)c != delim) {
        dss.data[dss.len++] = c;
        if ((dss.len + 1) % CHUNK_SIZE == 0) {
            dss.data[dss.len] = '\0';
            dss.reserve(dss.len + 1 + CHUNK_SIZE);
        }
    }
    dss.reserve(dss.len + 1);
    dss.data[dss.len] = '\0';

    return is;
}

void DSString::remove_punc()
{
    for (size_t i = 0; i < len; ) {
        if (data[i] != '\'' && data[i] >= -1 && data[i] <= 255 && ispunct(data[i])) {
            for (size_t j = i; j < len; j++) {
                data[j] = data[j + 1];
            }
            len--;
        }
        else {
            i++;
        }
    }
}

void DSString::remove_ws()
{
    for (size_t i = 0; i < len; ) {
        if (data[i] >= -1 && data[i] <= 255 && isspace(data[i])) {
            for (size_t j = i; j < len; j++) {
                data[j] = data[j + 1];
            }
            len--;
        }
        else {
            i++;
        }
    }
}

void DSString::tolower()
{
    for (size_t i = 0; i < len; i++) {
        if (data[i] >= -1 && data[i] <= 255) {
            data[i] = ::tolower(data[i]);
        }
    }
}

void DSString::remove_repeat_letters()
{
    assert(length() > 0);

    char c = data[0];
    int repeats = 0;

    DSVector<char> result;
    result.reserve(length() + 1);
    result.push_back(c);

    for (size_t i = 1; i < length(); i++) {
        if (data[i] == c) {
            repeats++;
        }
        else {
            c = data[i];
            repeats = 0;
        }
        if (repeats < 2) {
            result.push_back(c);
        }
    }

    result.push_back('\0');

    *this = result.data();
}

char& DSString::operator[](size_t idx)
{
    return data[idx];
}

char DSString::operator[](size_t idx) const
{
    return data[idx];
}