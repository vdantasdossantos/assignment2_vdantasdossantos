#define _CRT_SECURE_NO_WARNINGS	// So visual studio doesn't complain about deprecated C functions.
								// Okay to leave this #define in the code even if not using VS.

#include <algorithm>	// for std::lower_bound and std::sort
#include <cstdlib>
#include <cassert>
#include <iomanip>
#include <climits>
#include "Classifier.h"

#define CHAPTER_SIZE 500	// The number of words in a "chapter".
							// Used to improve training speed by reading
							// new words into a smaller vector first.

DSString stopwords[] = {
	"a", "about", "above", "after", "again", "against", "all", "am", "an", "and",
	"any", "are", "aren't", "as", "at", "be", "because", "been", "before", "being",
	"below", "between", "both", "but", "by", "can't", "cannot", "could", "couldn't",
	"did", "didn't", "do", "does", "doesn't", "doing", "don't", "down", "during",
	"each", "few", "for", "from", "further", "had", "hadn't", "has", "hasn't", "have",
	"haven't", "having", "he", "he'd", "he'll", "he's", "her", "here", "here's", "hers",
	"herself", "him", "himself", "his", "how", "how's", "i", "i'd", "i'll", "i'm",
	"i've", "if", "in", "into", "is", "isn't", "it", "it's", "its", "itself", "let's",
	"me", "more", "most", "mustn't", "my", "myself", "no", "nor", "not", "of", "off",
	"on", "once", "only", "or", "other", "ought", "our", "ours", "ourselves", "out",
	"over", "own", "same", "shan't", "she", "she'd", "she'll", "she's", "should",
	"shouldn't", "so", "some", "such", "than", "that", "that's", "the", "their",
	"theirs", "them", "themselves", "then", "there", "there's", "these", "they",
	"they'd", "they'll", "they're", "they've", "this", "those", "through", "to", "too",
	"under", "until", "up", "very", "was", "wasn't", "we", "we'd", "we'll", "we're",
	"we've", "were", "weren't", "what", "what's", "when", "when's", "where", "where's",
	"which", "while", "who", "who's", "whom", "why", "why's", "with", "won't", "would",
	"wouldn't", "you", "you'd", "you'll", "you're", "you've", "your", "yours",
	"yourself", "yourselves"
};
constexpr size_t stopwords_count = sizeof(stopwords) / sizeof(stopwords[0]);

void Classifier::train(std::istream& csv)
{
	Classifier chapter;
	DSVector<DSString> tokens;
	DSString line;
	int sentiment;

	chapter.vocabulary.reserve(CHAPTER_SIZE);
	pos_tweet_count = 0;
	
	getline(csv, line, '\n');	// Read but ignore the first line (column headers)

	while (getline(csv, line, ',') && line.length() > 0) {		// Sentiment value

		sentiment = atoi(line.c_str());
		if (sentiment > 0) {
			pos_tweet_count++;
		}
		else {
			neg_tweet_count++;
		}

		getline(csv, line, ',');	// tweet ID
		getline(csv, line, ',');	// date
		getline(csv, line, ',');	// query status
		getline(csv, line, ',');	// username
		getline(csv, line, '\n');	// tweet

		// Separate the tweet into individual words to be added to the vocabulary
		tokens = line.get_tokens(' ');
		for (DSString& token : tokens) {
			
			token.remove_punc();
			token.remove_ws();
			token.tolower();
			stem(token);

			if (token.length() > 0) {

				// Initially, new words are added to the smaller vocabulary "chapter"
				chapter.insert(token, (sentiment > 0 ? 1 : -1));

				// Once the chapter has reached capacity, move its contents to
				// the full vocabulary.
				if (chapter.vocabulary.size() == CHAPTER_SIZE) {
					acquire_chapter(chapter);
				}
			}
		}
	}

	// Move any words in the last chapter to the full vocabulary
	acquire_chapter(chapter);
}

void Classifier::test(std::istream& csv_tweets, std::istream& csv_sents,
	std::ostream& csv_results, std::ostream& csv_acc_err)
{
	// Precondition: The tweet ids in the two testing files are arranged in the same order.

	DSVector<int> sent_actual, sent_guess;
	DSVector<DSString> ids;
	DSVector<DSString> tokens;
	DSString line1, line2;
	float accur = 0;
	int guess;

	// Read but the first line (column headers) in the two input files
	getline(csv_tweets, line1, '\n');
	getline(csv_sents, line2, '\n');

	// Put the same header in the first results file as in the sentiment file
	csv_results << line2.c_str() << '\n';

	while (getline(csv_tweets, line1, ',') && line1.length() > 0) {	// tweet ID

		getline(csv_sents, line2, ','); // actual sentiment
		sent_actual.push_back(atoi(line2.c_str()));
		getline(csv_sents, line2, '\n'); // tweet ID

		// Verify that tweet ids match (precondition)
		line1.remove_ws();
		line2.remove_ws();
		assert(line1 == line2);

		ids.push_back(line1);

		getline(csv_tweets, line1, ',');	// date
		getline(csv_tweets, line1, ',');	// query status
		getline(csv_tweets, line1, ',');	// username
		getline(csv_tweets, line1, '\n');	// tweet

		guess = 0;

		// Separate the tweet into individual words and stem the words
		tokens = line1.get_tokens(' ');
		for (DSString& token : tokens) {
			token.remove_punc();
			token.remove_ws();
			token.tolower();
			stem(token);
		}

		// Report positive tweets as 4, negative tweets as 0.
		if (is_positive_tweet(tokens)) {
			guess = 4;
		}
		else {
			guess = 0;
		}

		sent_guess.push_back(guess);

		// Report the rating in the first output file
		csv_results << guess << ',' << ids.back().c_str() << '\n';
	}

	// Loop through the two vectors of sentiment ratings and compute accuracy
	for (size_t i = 0, I = sent_guess.size(); i < I; i++) {
		if (sent_guess[i] == sent_actual[i]) {
			accur++;
		}
	}

	csv_acc_err << std::setprecision(3) << std::fixed;
	csv_acc_err << (accur / sent_guess.size()) << '\n';

	// Loop through the two vectors of sentiment ratings and print erroneous ratings
	for (size_t i = 0, I = sent_guess.size(); i < I; i++) {
		if (sent_guess[i] != sent_actual[i]) {
			csv_acc_err << sent_guess[i] << ',' << sent_actual[i] << ',' << ids[i] << '\n';
		}
	}

	return;
}

void Classifier::insert(const DSString& word, int sentiment)
{
	// First check if word is a stopword, if so, ignore it.
	if (std::binary_search(stopwords, stopwords + stopwords_count, word)) {
		return;
	}

	SentimentalWord SW{ word, 0, 0 };
	if (sentiment > 0) {
		SW.pos_count++;
	}
	else {
		SW.neg_count++;
	}

	// Next check if word already exists
	auto it = std::lower_bound(vocabulary.begin(), vocabulary.end(), SW);

	if (it != vocabulary.end() && it->word == word) {
		// If words already exists, just adjust its sentiment
		if (sentiment > 0) {
			it->pos_count++;
		}
		else {
			it->neg_count++;
		}
	}
	else {
		// If new word, add to the vocabulary and restore sorted order
		vocabulary.push_back(SW);
		std::sort(vocabulary.begin(), vocabulary.end());	// probably n*log(n) complexity
	}
}

bool Classifier::is_positive_tweet(const DSVector<DSString>& words_in_tweet) const
{
	double P_pos = (double)pos_tweet_count / (pos_tweet_count + neg_tweet_count);
	double P_neg = 1.0 - P_pos;
	double P_words_given_pos = 1;
	double P_words_given_neg = 1;
	int pos_sent, neg_sent;

	for (size_t i = 0; i < words_in_tweet.size(); i++) {
		pos_sent = lookup_pos_sentiment(words_in_tweet[i]);
		neg_sent = lookup_neg_sentiment(words_in_tweet[i]);
		if (pos_sent != neg_sent) {
			P_words_given_pos *= (double)pos_sent / pos_tweet_count;
			P_words_given_neg *= (double)neg_sent / neg_tweet_count;
		}
	}

	// Apply Bayes' rule
	double P_pos_given_words = P_pos * P_words_given_pos /
		(P_pos * P_words_given_pos + P_neg * P_words_given_neg);

	return (P_pos_given_words > .5);
}

int Classifier::lookup_pos_sentiment(const DSString& word) const
{
	auto it = std::lower_bound(
		vocabulary.begin(), vocabulary.end(), SentimentalWord{ word, 0, 0 });

	if (it != vocabulary.end() && it->word == word) {
		return it->pos_count;
	}
	return 0;
}

int Classifier::lookup_neg_sentiment(const DSString& word) const
{
	auto it = std::lower_bound(
		vocabulary.begin(), vocabulary.end(), SentimentalWord{ word, 0, 0 });

	if (it != vocabulary.end() && it->word == word) {
		return it->neg_count;
	}
	return 0;
}

void Classifier::acquire_chapter(Classifier& chapter)
{
	size_t pre_acq_size = vocabulary.size();

	for (size_t i = 0, I = chapter.vocabulary.size(); i < I; i++) {

		// First check if word already exists
		auto it = std::lower_bound(
			vocabulary.begin(), vocabulary.begin() + pre_acq_size, chapter.vocabulary[i]);

		if (it != vocabulary.end() && it->word == chapter.vocabulary[i].word) {
			// If words already exists, just adjust its counters
			it->pos_count += chapter.vocabulary[i].pos_count;
			it->neg_count += chapter.vocabulary[i].neg_count;
		}
		else {
			// If new word, add to the end of the full vocabulary but leave the
			// preacquistion vocabulary in the same order.
			vocabulary.push_back(chapter.vocabulary[i]);
		}
	}
	// Sort once at the very end
	std::sort(vocabulary.begin(), vocabulary.end());
	chapter.vocabulary.resize(0);
}

void Classifier::stem(DSString& token)
{
	// stem the word (have to convert it to wstring type first)
	unicode_buffer.resize(token.length() + 1);
	std::wmemset(unicode_buffer.data(), 0, token.length() + 1);
	std::mbstowcs(unicode_buffer.data(), token.c_str(), token.length());
	unicode_word = unicode_buffer.data();
	stemmer(unicode_word);

	char multibyte[MB_LEN_MAX];
	ascii_buffer.resize(0);
	for (size_t i = 0; i < unicode_word.length(); i++) {
		int len = std::wctomb(multibyte, unicode_word[i]);
		for (int j = 0; j < len; j++) {
			ascii_buffer.push_back(multibyte[j]);
		}
	}
	ascii_buffer.push_back('\0');
	token = ascii_buffer.data();
}
