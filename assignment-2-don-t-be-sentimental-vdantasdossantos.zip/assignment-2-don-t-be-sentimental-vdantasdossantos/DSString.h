#define _CRT_SECURE_NO_WARNINGS

#ifndef DSSTRING_H
#define DSSTRING_H

#include <iostream>
#include "DSVector.h"

class DSString
{

private:
    char * data;    // A pointer to a character array containing the string.
    size_t alloc;   // The number of characters allocated to the array.
    size_t len;     // The length of the string, not including the null character.

    static const char EMPTY_STRING[1];  // Only element is the null character

    void copy(const char*);
    void clear();

public:
    /**
     * Make sure you implement the rule of 3 and use proper memory management.
     * To help you get started, you can implement the following:
     **/

    DSString();
    DSString(const char *); // constructor that converts a cstring

    // rule of 3
    DSString(const DSString &);  // copy constructor
    ~DSString();  // destructor
    DSString &operator=(const DSString &);  // copy assignment operator

    // you can also implement the move versions for the big 5 (C+11)
    DSString(DSString&&) noexcept;   // move constructor
    DSString& operator=(DSString&&) noexcept;  // move assignment operator

    void reserve(size_t);

    // implement some useful methods

    /**
     * Overloaded non-modifying string concat
     */
    DSString& operator+=(const DSString &);

    /**
     * Standard relational operators to compare and order your strings.  
     * Feel free to add additional.
     **/
    bool operator==(const DSString &) const;
    bool operator!=(const DSString &) const;

    bool operator<(const DSString &) const;
    bool operator>(const DSString &) const;


    /**
     * The substring method returns a string object that contains a
     * sequence of characters from this string object.
     *
     * param pos - the index of where to start
     * param count - the number (count) of characters to copy into
     *    the substring
     * @return a DSString object containing the requested substring
     **/
    DSString substring(size_t pos, size_t count) const;

    /**
     * the c_str function returns a pointer a null-terminated c-string holding the
     * contents of this object. It would be smart to always have an extra `\0`
     * at the end of the string in DSString so you can just return a pointer to the
     * objects. 
     **/
    const char *c_str() const;

    /**
     * Overloaded stream insertion operator to print the contents of this
     * string to the output stream in the first argument. `DSString&`
     * could be const, but then we would have to implement a const interator in
     * DSVector.
     **/
    friend std::ostream &operator<<(std::ostream &, const DSString &);

    friend std::istream& operator>>(std::istream&, DSString&);

    // You are free to add more functionality to the class.  For example,
    // you may want to add a find(...) function that will search for a
    // substring within a string or a function that breaks a string into words.
    DSVector<DSString> get_tokens(char delim) const;

    size_t length() const  { return len; }

    friend std::istream& getline(std::istream& is, DSString& dss, char delim);

    void remove_punc();
    void remove_ws();
    void tolower();
    void remove_repeat_letters();
        // If a letter is repeated 3 or more times consecutively, removes it until it only
        // appears 2 times consecutively. E.g. "sweeeeeeet" is changed to "sweet".

    char& operator[](size_t idx);
    char operator[](size_t idx) const;
};

#endif